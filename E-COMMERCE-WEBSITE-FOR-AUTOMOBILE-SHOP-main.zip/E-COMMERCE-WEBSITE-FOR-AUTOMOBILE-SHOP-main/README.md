This is my FULL STACK DEVELOPMENT PROJECT REPORT done in the academic year 2023-2024 at CMR Institute of Technology
